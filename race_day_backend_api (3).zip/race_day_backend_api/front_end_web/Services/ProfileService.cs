﻿using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using front_end_web.Models.Profile;

namespace front_end_web.Services;

public class ProfileService : IProfileService
{
    private readonly IHttpClientFactory _factory;

    public ProfileService(IHttpClientFactory factory) => _factory = factory;

    private HttpClient CreateClient(string token)
    {
        var client = _factory.CreateClient("RaceDayApi");
        client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Bearer", token);
        return client;
    }

    public async Task<ProfileViewModel?> GetMyProfileAsync(
        string token, CancellationToken ct = default)
    {
        using var client = CreateClient(token);
        using var response = await client.GetAsync("api/profile/me", ct);
        if (response.StatusCode == System.Net.HttpStatusCode.NotFound) return null;
        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<ProfileViewModel>(
            new JsonSerializerOptions(JsonSerializerDefaults.Web), ct);
    }

    public async Task<(bool Success, string Message, string? ImageUrl)> UploadProfileImageAsync(
        IFormFile image, string token, CancellationToken ct = default)
    {
        using var client = CreateClient(token);
        using var content = new MultipartFormDataContent();
        await using var stream = image.OpenReadStream();
        using var fileContent = new StreamContent(stream);
        fileContent.Headers.ContentType =
            new MediaTypeHeaderValue(image.ContentType);
        content.Add(fileContent, "image", Path.GetFileName(image.FileName));

        using var response = await client.PostAsync(
            "api/profile/me/profile-image", content, ct);
        var body = await response.Content.ReadAsStringAsync(ct);

        if (response.IsSuccessStatusCode)
        {
            try
            {
                using var json = JsonDocument.Parse(body);
                var url = json.RootElement.TryGetProperty("imageUrl", out var imageUrl)
                    ? imageUrl.GetString()
                    : null;
                var message = json.RootElement.TryGetProperty("message", out var msg)
                    ? msg.GetString() ?? "Profile picture updated."
                    : "Profile picture updated.";
                return (true, message, url);
            }
            catch (JsonException)
            {
                return (true, "Profile picture updated.", null);
            }
        }

        try
        {
            using var json = JsonDocument.Parse(body);
            if (json.RootElement.TryGetProperty("message", out var msg))
                return (false, msg.GetString() ?? "Upload failed.", null);
        }
        catch (JsonException) { }

        return (false, $"Upload failed (HTTP {(int)response.StatusCode}).", null);
    }
}
