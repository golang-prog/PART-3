﻿using front_end_web.Models.Profile;
using front_end_web.Services;
using Microsoft.AspNetCore.Mvc;

public class ProfileController : Controller
{
    private readonly IProfileService _profileService;
    private readonly ILogger<ProfileController> _logger;

    public ProfileController(
        IProfileService profileService,
        ILogger<ProfileController> logger)
    {
        _profileService = profileService;
        _logger = logger;
    }

    private string? Token => HttpContext.Session.GetString("JwtToken");

    private IActionResult? CheckProfileAccess()
    {
        if (string.IsNullOrWhiteSpace(Token))
            return RedirectToAction("Login", "Account");

        var role = HttpContext.Session.GetString("UserRole");
        if (role is not ("Participant" or "Organiser"))
            return Forbid();

        return null;
    }

    [HttpGet]
    public async Task<IActionResult> Index(CancellationToken ct)
    {
        var access = CheckProfileAccess();
        if (access != null) return access;

        try
        {
            var model = await _profileService.GetMyProfileAsync(Token!, ct);
            if (model == null) return NotFound();
            return View(model);
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "Could not load current user profile.");
            TempData["ErrorMessage"] = "Unable to load your profile right now.";
            return View(new ProfileViewModel
            {
                FirstName = HttpContext.Session.GetString("UserName") ?? ""
            });
        }
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [RequestSizeLimit(5 * 1024 * 1024)]
    public async Task<IActionResult> UploadImage(ProfileViewModel model, CancellationToken ct)
    {
        var access = CheckProfileAccess();
        if (access != null) return access;

        if (model.Image == null || model.Image.Length == 0)
        {
            ModelState.AddModelError(nameof(model.Image), "Please choose a profile picture.");
            var profile = await _profileService.GetMyProfileAsync(Token!, ct)
                          ?? new ProfileViewModel();
            profile.Image = null;
            return View("Index", profile);
        }

        if (model.Image.Length > 5 * 1024 * 1024)
        {
            ModelState.AddModelError(nameof(model.Image), "The image must be 5 MB or smaller.");
            var profile = await _profileService.GetMyProfileAsync(Token!, ct)
                          ?? new ProfileViewModel();
            return View("Index", profile);
        }

        var extension = Path.GetExtension(model.Image.FileName).ToLowerInvariant();
        if (!new[] { ".jpg", ".jpeg", ".png", ".webp" }.Contains(extension))
        {
            ModelState.AddModelError(nameof(model.Image), "Choose a JPG, PNG, or WEBP file.");
            var profile = await _profileService.GetMyProfileAsync(Token!, ct)
                          ?? new ProfileViewModel();
            return View("Index", profile);
        }

        try
        {
            var result = await _profileService.UploadProfileImageAsync(
                model.Image, Token!, ct);
            TempData[result.Success ? "SuccessMessage" : "ErrorMessage"] = result.Message;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "Profile picture upload failed.");
            TempData["ErrorMessage"] = "The profile picture could not be uploaded.";
        }

        return RedirectToAction(nameof(Index));
    }
}
