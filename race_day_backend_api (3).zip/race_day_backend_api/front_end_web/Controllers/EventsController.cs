﻿using front_end_web.Models.Events;
using front_end_web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace front_end_web.Controllers;

public class EventsController : Controller
{
    private readonly IEventService _eventService;
    private readonly ILogger<EventsController> _logger;

    public EventsController(
        IEventService eventService,
        ILogger<EventsController> logger)
    {
        _eventService = eventService;
        _logger = logger;
    }

    private string? Token => HttpContext.Session.GetString("JwtToken");
    private string? Role => HttpContext.Session.GetString("UserRole");

    private IActionResult? CheckParticipantAccess()
    {
        if (string.IsNullOrWhiteSpace(Token))
            return RedirectToAction("Login", "Auth");

        if (!string.Equals(Role, "Participant", StringComparison.OrdinalIgnoreCase))
            return RedirectToAction("AccessDenied", "Auth");

        return null;
    }

    [HttpGet]
    public async Task<IActionResult> Index(
        int? categoryId, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(Token))
            return RedirectToAction("Login", "Auth");

        try
        {
            var events = await _eventService.GetEventsAsync(Token!, cancellationToken);
            var categories = await _eventService.GetCategoriesAsync(Token!, cancellationToken);

            ViewBag.Categories = new SelectList(
                categories, "CategoryId", "Title", categoryId);
            ViewBag.SelectedCategoryId = categoryId;

            if (categoryId.HasValue)
                events = events.Where(e => e.CategoryId == categoryId.Value).ToList();

            return View(events.OrderBy(e => e.Date).ToList());
        }
        catch (Exception ex) when (ex is HttpRequestException or System.Text.Json.JsonException)
        {
            _logger.LogError(ex, "Unable to load events.");
            TempData["Error"] = "Events could not be loaded. Please try again.";
            ViewBag.Categories = new SelectList(
                Array.Empty<CategoryOptionViewModel>(), "CategoryId", "Title");
            return View(new List<EventViewModel>());
        }
    }

    [HttpGet]
    public async Task<IActionResult> Details(
        int id, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(Token))
            return RedirectToAction("Login", "Auth");
        if (id <= 0) return BadRequest();

        try
        {
            var model = await _eventService.GetEventAsync(id, Token!, cancellationToken);
            if (model == null) return NotFound();
            return View(model);
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "Unable to load event {EventId}.", id);
            TempData["Error"] = "The event could not be loaded.";
            return RedirectToAction(nameof(Index));
        }
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Enrol(
        EnrolEventViewModel model, CancellationToken cancellationToken)
    {
        var access = CheckParticipantAccess();
        if (access != null) return access;

        if (!ModelState.IsValid)
        {
            TempData["Error"] = "Please select a valid event.";
            return RedirectToAction(nameof(Details), new { id = model.EventId });
        }

        try
        {
            var result = await _eventService.EnrolAsync(model, Token!, cancellationToken);
            TempData[result.Success ? "Success" : "Error"] = result.Message;
            return RedirectToAction(
                result.Success ? nameof(MyEnrolments) : nameof(Details),
                result.Success ? null : new { id = model.EventId });
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "Enrolment failed for event {EventId}.", model.EventId);
            TempData["Error"] = "Enrolment failed. You may already be enrolled.";
            return RedirectToAction(nameof(Details), new { id = model.EventId });
        }
    }

    // GET: /Events/MyEvents
    // Displays only events the signed-in participant has enrolled in.
    [HttpGet]
    public async Task<IActionResult> MyEvents(
        CancellationToken cancellationToken)
    {
        var access = CheckParticipantAccess();
        if (access != null) return access;

        try
        {
            var rows = await _eventService.GetMyEnrolmentsAsync(
                Token!, cancellationToken);

            // Sort upcoming events first, then past events.
            var orderedRows = rows
                .OrderBy(row => !(row.EventDate.HasValue && row.EventDate.Value.Date >= DateTime.Today))
                .ThenBy(row => row.EventDate ?? DateTime.MaxValue)
                .ThenBy(row => row.StartTime)
                .ToList();

            return View(orderedRows);
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "Unable to load the participant's enrolled events.");
            TempData["Error"] = "Your events could not be loaded. Please try again.";
            return View(new List<ParticipantEnrolmentViewModel>());
        }
        catch (System.Text.Json.JsonException ex)
        {
            _logger.LogError(ex, "Invalid response while loading enrolled events.");
            TempData["Error"] = "The event data returned by the server could not be read.";
            return View(new List<ParticipantEnrolmentViewModel>());
        }
    }

    [HttpGet]
    public async Task<IActionResult> MyEnrolments(
        CancellationToken cancellationToken)
    {
        var access = CheckParticipantAccess();
        if (access != null) return access;

        try
        {
            var rows = await _eventService.GetMyEnrolmentsAsync(Token!, cancellationToken);
            return View(rows);
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "Unable to load participant enrolments.");
            TempData["Error"] = "Your enrolments could not be loaded.";
            return View(new List<ParticipantEnrolmentViewModel>());
        }
    }
}
