﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace race_day_backend_api.Services
{
    public interface IBlobStorageService
    {
        Task<string> UploadFileAsync(IFormFile file, string? folder = null);
        Task DeleteFileAsync(string blobName);
    }
    public class ImageStorageService : IBlobStorageService
    {
        private readonly BlobContainerClient _containerClient;

        public ImageStorageService(IConfiguration configuration)
        {
            var connectionString = configuration["AzureClients:AzureConnectionString"];
            var containerName = configuration["AzureClients:ContainerName"] ?? "race_day_images";

            var blobServiceClient = new BlobServiceClient(connectionString);
            _containerClient = blobServiceClient.GetBlobContainerClient(containerName);
            _containerClient.CreateIfNotExists(PublicAccessType.Blob);
        }

        public async Task<string> UploadFileAsync(IFormFile file, string? folder = null)
        {
            if (file == null || file.Length == 0)
                throw new ArgumentException("No file provided");

            var extension = Path.GetExtension(file.FileName).ToLowerInvariant();
            var fileName = $"{Guid.NewGuid():N}{extension}";
            var blobName = string.IsNullOrEmpty(folder)
                ? fileName
                : $"{folder.TrimEnd('/')}/{fileName}";

            var blobClient = _containerClient.GetBlobClient(blobName);
            var httpHeaders = new BlobHttpHeaders { ContentType = file.ContentType };

            await using var stream = file.OpenReadStream();
            await blobClient.UploadAsync(stream, httpHeaders);

            return blobClient.Uri.ToString();
        }

        public async Task DeleteFileAsync(string blobName)
        {
            var blobClient = _containerClient.GetBlobClient(blobName);
            await blobClient.DeleteIfExistsAsync();
        }
    }
}
