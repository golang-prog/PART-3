﻿using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using race_day_backend_api.Data;

namespace race_day_backend_api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ProfileController : ControllerBase
{
    private readonly ApplicationDbContext _context;
    private readonly IWebHostEnvironment _environment;

    public ProfileController(ApplicationDbContext context, IWebHostEnvironment environment)
    {
        _context = context;
        _environment = environment;
    }

    [HttpGet("me")]
    public async Task<IActionResult> GetMyProfile(CancellationToken ct)
    {
        var userId = GetCurrentUserId();
        if (userId == null) return Unauthorized();

        var account = await _context.UserAccounts
            .AsNoTracking()
            .Where(u => u.UserId == userId.Value)
            .Select(u => new
            {
                u.UserId,
                u.FirstName,
                u.LastName,
                u.EmailAddress,
                u.ImageUrl
            })
            .FirstOrDefaultAsync(ct);

        return account == null
            ? NotFound(new { message = "User account was not found." })
            : Ok(account);
    }

    [HttpPost("me/profile-image")]
    [Consumes("multipart/form-data")]
    [RequestSizeLimit(5 * 1024 * 1024)]
    public async Task<IActionResult> UploadProfileImage(
        [FromForm] IFormFile? image,
        CancellationToken ct)
    {
        var userId = GetCurrentUserId();
        if (userId == null) return Unauthorized();

        if (image == null || image.Length == 0)
            return BadRequest(new { message = "Choose an image to upload." });

        const long maxBytes = 5 * 1024 * 1024;
        if (image.Length > maxBytes)
            return BadRequest(new { message = "Image must be 5 MB or smaller." });

        var extension = Path.GetExtension(image.FileName).ToLowerInvariant();
        var allowed = new[] { ".jpg", ".jpeg", ".png", ".webp" };
        if (!allowed.Contains(extension))
            return BadRequest(new { message = "Use a JPG, PNG, or WEBP image." });

        // Validate the content type as a basic additional check.
        var allowedTypes = new[] { "image/jpeg", "image/png", "image/webp" };
        if (!allowedTypes.Contains(image.ContentType.ToLowerInvariant()))
            return BadRequest(new { message = "The uploaded file is not a supported image type." });

        var account = await _context.UserAccounts
            .FirstOrDefaultAsync(u => u.UserId == userId.Value, ct);
        if (account == null)
            return NotFound(new { message = "User account was not found." });

        var uploadsFolder = Path.Combine(_environment.WebRootPath ?? "wwwroot", "uploads", "profiles");
        Directory.CreateDirectory(uploadsFolder);

        // Use a generated filename; never trust a client-supplied path.
        var fileName = $"profile_{userId.Value}_{Guid.NewGuid():N}{extension}";
        var filePath = Path.Combine(uploadsFolder, fileName);

        await using (var stream = System.IO.File.Create(filePath))
        {
            await image.CopyToAsync(stream, ct);
        }

        // Store a relative URL so the URL works when the host changes.
        var oldImageUrl = account.ImageUrl;
        account.ImageUrl = $"/uploads/profiles/{fileName}";
        await _context.SaveChangesAsync(ct);

        // Remove the previous image only if it was stored in our profile uploads folder.
        if (!string.IsNullOrWhiteSpace(oldImageUrl) &&
            oldImageUrl.StartsWith("/uploads/profiles/", StringComparison.OrdinalIgnoreCase))
        {
            var oldName = Path.GetFileName(oldImageUrl);
            var oldPath = Path.Combine(uploadsFolder, oldName);
            if (!string.Equals(oldPath, filePath, StringComparison.OrdinalIgnoreCase) &&
                System.IO.File.Exists(oldPath))
            {
                try { System.IO.File.Delete(oldPath); } catch { /* cleanup is non-critical */ }
            }
        }

        var baseUrl = $"{Request.Scheme}://{Request.Host}";
        return Ok(new
        {
            message = "Profile picture updated successfully.",
            imageUrl = account.ImageUrl,
            absoluteImageUrl = $"{baseUrl}{account.ImageUrl}"
        });
    }

    private int? GetCurrentUserId()
    {
        var claim = User.FindFirstValue(ClaimTypes.NameIdentifier)
                    ?? User.FindFirstValue("sub")
                    ?? User.FindFirstValue("UserId");
        return int.TryParse(claim, out var id) ? id : null;
    }
}
