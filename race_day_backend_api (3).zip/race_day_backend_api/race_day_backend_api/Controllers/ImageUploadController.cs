﻿using Microsoft.AspNetCore.Mvc;

namespace race_day_backend_api.Controllers
{
    public class ImageUploadController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
